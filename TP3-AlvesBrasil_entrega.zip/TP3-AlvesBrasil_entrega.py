# Ejercicio 1 "Caja del Kiosco"

# Simular una compra con validaciones y calculo del total.

# Pedir nombre del cliente.

nombre=input("Por favor, escribe tu nombre: ")

while not nombre.isalpha():
    nombre=input("Nombre invalido, escribe tu nombre utilizando unicamente letras: ")

print("Hola" ,nombre,"!")

# Pedir cantidad de productor a comprar.

producto=input("Por favor indica cuantos productos comprarás hoy: ")

while not producto.isdigit() or int(producto) <= 0 :
    producto=input("Ingrese una cantidad valida en numeros: ")

producto=int(producto)

print("Cantidad de productos: ",producto,)

# Por cada producto pedir precio y descuento (si tiene aplicar el %10)

sin_descuento=0
con_descuento=0
ahorro=0

for i in range(producto):
    precio=input("Ingrese el precio del producto: ")

    while not precio.isdigit():
        precio=input("Ingrese un valor en cifras numericas: ")

    precio=int(precio)

    descuento=input("¿Hay descuentos? S/N: ")
    descuento=descuento.lower()

    while descuento != "s" and descuento != "n":
        descuento=input("Respuesta invalida. Ingrese S o N: ").lower()

    if descuento == "s":
        porcentaje = 10
        resultado = (precio*porcentaje)/100

        precio_final=precio-resultado
        ahorro+=resultado

    else:
       precio_final=precio

    con_descuento+=precio_final
    sin_descuento+=precio
    promedio=(con_descuento)/producto


print("Total con descuentos: $", con_descuento,)
print("Total sin descuentos: $",sin_descuento,)
print("Ahorro: $",ahorro,)
print("Promedio por producto: $",promedio,)


# Ejercicio 2 "Acceso al Campus y Menú Seguro".

# Login con intentos + menu de acciones con validacion estricta.

# Definir credenciales fijas en el codigo.


usuario_correcto="alumno"
clave_correcta="python123"

usuario=input("Por favor ingrese su nombre de usuario: ").lower()
clave=input("Por favor ingrese la clave: ").lower()

intentos = 1
acceso=False

if usuario==usuario_correcto and clave==clave_correcta:
    print("Acceso permitido.")
    acceso=True

while intentos<3 and acceso==False:
     
     print("Intentelo de nuevo.")
     usuario=input("Por favor ingrese su nombre de usuario: ").lower()
     clave=input("Por favor ingrese la clave: ").lower()

     if usuario==usuario_correcto and clave==clave_correcta:
        print("Acceso permitido.") 

     else:
        intentos+=1

     if intentos==3:
        print("Cuenta bloqueada.")

# PROFE este ejercicio se que esta incompleto, pero en la resolucion me pide mas intentos aunque ponga los datos correctos y no logro entenden en que parte del codigo esta el error. Espero sus observaciones por favor.

# Ejercicio 3

# Agenda de Turnos con Nombres.

# Turnos por dia

lunes1 = ""
lunes2 = ""
lunes3 = ""
lunes4 = ""

martes1 = ""
martes2 = ""
martes3 = ""

operador = input("Ingrese el nombre del operador: ")

while not operador.isalpha():
    print("El nombre solo puede contener letras.")
    operador = input("Ingrese el nombre del operador: ")

# Menu repetitivo

opcion=""

while opcion != 5:
    print("Sistema de turnos:")
    print("1. Reservar turno")
    print("2. Cancelar turno")
    print("3. Ver agenda del día")
    print("4. Ver resumen general")
    print("5. Cerrar sistema")

    opcion=input("Seleccione una opcion: ")

    while not opcion.isdigit() or int(opcion) < 1 or int(opcion) > 5:
        print("Opción inválida.")
        opcion = input("Seleccione una opción: ")

    opcion = int(opcion)

# Reserva de turno.

    if opcion==1:
        dia = input("Ingrese el día (1=Lunes, 2=Martes): ")

        while not dia.isdigit() or int(dia) < 1 or int(dia) > 2:
            print("Día inválido.")
            dia = input("Ingrese el día (1=Lunes, 2=Martes): ")

        dia = int(dia)

        paciente = input("Ingrese el nombre del paciente: ")

        while not paciente.isalpha():
            print("El nombre solo puede contener letras.")
            paciente = input("Ingrese el nombre del paciente: ")

        if dia == 1:

# Verificar si el operador esta registrado
 
            if paciente == lunes1 or paciente == lunes2 or paciente == lunes3 or paciente == lunes4:
                print("El paciente ya tiene un turno para el lunes.")

            else:

                # Buscar turno libre:  

                if lunes1 == "":
                    lunes1 = paciente
                    print("Turno reservado correctamente. Turno 1.")

                elif lunes2 == "":
                    lunes2 = paciente
                    print("Turno reservado correctamente. Turno 2.")

                elif lunes3 == "":
                    lunes3 = paciente
                    print("Turno reservado correctamente. Turno 3.")

                elif lunes4 == "":
                    lunes4 = paciente
                    print("Turno reservado correctamente. Turno 4.")

                else:
                    print("No hay turnos disponibles para el lunes.")


        else:
            # Verificar si el paciente ya está registrado

            if paciente == martes1 or paciente == martes2 or paciente == martes3:
                print("El paciente ya tiene un turno para el martes.")

            else:
                # Buscar primer espacio libre

                if martes1 == "":
                    martes1 = paciente
                    print("Turno reservado correctamente. Turno 1.")

                elif martes2 == "":
                    martes2 = paciente
                    print("Turno reservado correctamente. Turno 2.")

                elif martes3 == "":
                    martes3 = paciente
                    print("Turno reservado correctamente. Turno 3.")

                else:
                    print("No hay turnos disponibles para el martes.")

# CANCELAR TURNO

    elif opcion == 2:

        dia = input("Ingrese el día (1=Lunes, 2=Martes): ")

        while not dia.isdigit() or int(dia) < 1 or int(dia) > 2:
            print("Día inválido.")
            dia = input("Ingrese el día (1=Lunes, 2=Martes): ")

        dia = int(dia)

        paciente = input("Ingrese el nombre del paciente: ")

        while not paciente.isalpha():
            print("El nombre solo puede contener letras.")
            paciente = input("Ingrese el nombre del paciente: ")


        if dia == 1:

            if paciente == lunes1:
                lunes1 = ""
                print("Turno cancelado correctamente.")

            elif paciente == lunes2:
                lunes2 = ""
                print("Turno cancelado correctamente.")

            elif paciente == lunes3:
                lunes3 = ""
                print("Turno cancelado correctamente.")

            elif paciente == lunes4:
                lunes4 = ""
                print("Turno cancelado correctamente.")

            else:
                print("No se encontró un turno para ese paciente.")


        else:

            if paciente == martes1:
                martes1 = ""
                print("Turno cancelado correctamente.")

            elif paciente == martes2:
                martes2 = ""
                print("Turno cancelado correctamente.")

            elif paciente == martes3:
                martes3 = ""
                print("Turno cancelado correctamente.")

            else:
                print("No se encontró un turno para ese paciente.")

 # VER AGENDA

    elif opcion == 3:

        dia = input("Ingrese el día (1=Lunes, 2=Martes): ")

        while not dia.isdigit() or int(dia) < 1 or int(dia) > 2:
            print("Día inválido.")
            dia = input("Ingrese el día (1=Lunes, 2=Martes): ")

        dia = int(dia)


        if dia == 1:

            print("\n===== AGENDA DEL LUNES =====")

            if lunes1 == "":
                print("Turno 1: (libre)")
            else:
                print("Turno 1:", lunes1)

            if lunes2 == "":
                print("Turno 2: (libre)")
            else:
                print("Turno 2:", lunes2)

            if lunes3 == "":
                print("Turno 3: (libre)")
            else:
                print("Turno 3:", lunes3)

            if lunes4 == "":
                print("Turno 4: (libre)")
            else:
                print("Turno 4:", lunes4)


        else:

            print("\n===== AGENDA DEL MARTES =====")

            if martes1 == "":
                print("Turno 1: (libre)")
            else:
                print("Turno 1:", martes1)

            if martes2 == "":
                print("Turno 2: (libre)")
            else:
                print("Turno 2:", martes2)

            if martes3 == "":
                print("Turno 3: (libre)")
            else:
                print("Turno 3:", martes3)

# RESUMEN GENERAL

    elif opcion == 4:

        ocupados_lunes = 0
        ocupados_martes = 0


        if lunes1 != "":
            ocupados_lunes += 1

        if lunes2 != "":
            ocupados_lunes += 1

        if lunes3 != "":
            ocupados_lunes += 1

        if lunes4 != "":
            ocupados_lunes += 1


        if martes1 != "":
            ocupados_martes += 1

        if martes2 != "":
            ocupados_martes += 1

        if martes3 != "":
            ocupados_martes += 1


        disponibles_lunes = 4 - ocupados_lunes
        disponibles_martes = 3 - ocupados_martes

    print("===== RESUMEN GENERAL =====")

    print("Lunes:")
    print("Turnos ocupados:", ocupados_lunes)
    print("Turnos disponibles:", disponibles_lunes)

    print("\nMartes:")
    print("Turnos ocupados:", ocupados_martes)
    print("Turnos disponibles:", disponibles_martes)


    if ocupados_lunes > ocupados_martes:
        print("El día con más turnos ocupados es el lunes.")

    elif ocupados_martes > ocupados_lunes:
        print("El día con más turnos ocupados es el martes.")

    else:
        print("Hay un empate: ambos días tienen la misma cantidad de turnos ocupados.")

 # Ejercicio 4

#Escape Room: La Boveda

# Variables iniciales

energia = 100
tiempo=12
cerraduras_abiertas= 0
alarma=False
codigo_parcial=""
forzar_seguidas=0

# Pedir y validar nombre

nombre = input("Ingrese el nombre del agente: ")

while not nombre.isalpha():
    print("El nombre debe contener solamente letras.")
    nombre = input("Ingrese nuevamente el nombre: ")

print("Bienvenido, agente", nombre)

# Juego

while energia > 0 and tiempo > 0 and cerraduras_abiertas < 3 and not alarma:
    print("Energía:", energia)
    print("Tiempo:", tiempo)
    print("Cerraduras abiertas:", cerraduras_abiertas)
    print("Código parcial:", codigo_parcial)

    print("-------------------------")

    print("1. Forzar cerradura")
    print("2. Hackear panel")
    print("3. Descansar")

    opcion = input("Seleccione una opción: ")

    # Validar opción

    while not opcion.isdigit() or int(opcion) < 1 or int(opcion) > 3:
        print("Opción inválida.")
        opcion = input("Seleccione una opción (1-3): ")

    opcion = int(opcion)

     # OPCIÓN 1: FORZAR CERRADURA

    if opcion == 1:
        energia -= 20
        tiempo -= 2
        forzar_seguidas += 1

        # Regla anti-spam

        if forzar_seguidas == 3:
            print("La cerradura se trabó.")
            print("¡ALARMA ACTIVADA!")
            alarma = True

        else:
            # Riesgo de alarma si energía está por debajo de 40

            if energia < 40:
                numero = input("¡Riesgo de alarma! Elija un número del 1 al 3: ")

                while not numero.isdigit() or int(numero) < 1 or int(numero) > 3: 
                    print("Número inválido.") 
                    numero = input("Ingrese un número del 1 al 3: ")

                numero = int(numero)

                if numero == 3:
                    alarma=True
                    print(" ALARMA ACTIVADA ")

            # SIN ALARMA ABRE LA CERRADURA

            if not alarma:
                 cerraduras_abiertas += 1
                 print("¡Cerradura abierta!")

    # OPCIÓN 2: HACKEAR PANEL 
    
    elif opcion == 2:
        energia -= 10
        tiempo -= 3
        forzar_seguidas = 0

        print("Iniciando hackeo...")

        for paso in range(4):
            codigo_parcial += "A"
            print("Paso", paso + 1, "- Progreso:", codigo_parcial)

        if len(codigo_parcial) >= 8 and cerraduras_abiertas < 3:
            cerraduras_abiertas += 1
            print("¡El código está completo! Cerradura abierta.")

    # OPCIÓN 3: DESCANSAR 
    elif opcion == 3:
        energia += 15

        if energia > 100:
            energia = 100
        tiempo -= 1
        forzar_seguidas = 0
        if alarma:
            energia -= 10
        print("Has descansado.")

    # FIN DEL JUEGO

    if cerraduras_abiertas == 3: 
        print("¡¡¡VICTORIA!!!") 
        print("Has abierto las 3 cerraduras.")

    elif alarma and tiempo <= 3 and cerraduras_abiertas < 3: 
        print("¡¡¡DERROTA!!!") 
        print("La bóveda quedó bloqueada por la alarma.")

    elif energia <= 0 or tiempo <= 0: 
        print("¡¡DERROTA!!!")

# Ejercicio 5

nombre = input("Ingrese el nombre del Gladiador: ")

while not nombre.isalpha():
    print("Error: Solo se permiten letras")
    nombre = input("Ingrese el nombre del Gladiador: ")


vida_gladiador = 100
vida_enemigo = 100
pociones = 3
ataque_pesado = 15
daño_enemigo = 12
turno_gladiador = True


while vida_gladiador > 0 and vida_enemigo > 0:

    if turno_gladiador:

        print("\n--- TURNO DEL GLADIADOR ---")
        print("Vida del Gladiador:", vida_gladiador)
        print("Vida del Enemigo:", vida_enemigo)
        print("Pociones disponibles:", pociones)

        print("\n1. Ataque Pesado")
        print("2. Ráfaga Veloz")
        print("3. Curar")

        opcion = input("Elija una opción: ")

        while not opcion.isdigit() or int(opcion) < 1 or int(opcion) > 3:
            print("Error: Debe ingresar una opción entre 1 y 3.")
            opcion = input("Elija una opción: ")

        opcion = int(opcion)

        # ATAQUE PESADO
        if opcion == 1:

            daño = ataque_pesado

            if vida_enemigo < 20:
                daño = ataque_pesado * 1.5
                print("¡Golpe Crítico!")

            vida_enemigo = vida_enemigo - daño

            print("¡Atacaste al enemigo por", daño, "puntos de daño!")


        # RÁFAGA VELOZ
        elif opcion == 2:

            for i in range(3):
                vida_enemigo = vida_enemigo - 5
                print("> Golpe conectado por 5 de daño")


        # CURAR
        elif opcion == 3:

            if pociones > 0:
                vida_gladiador = vida_gladiador + 30
                pociones = pociones - 1
                print("¡Te has curado 30 puntos de vida!")
            else:
                print("¡No quedan pociones!")


        # TURNO DEL ENEMIGO
        if vida_enemigo > 0:
            vida_gladiador = vida_gladiador - daño_enemigo
            print("¡El enemigo te atacó por 12 puntos de daño!")


# FIN DEL JUEGO
if vida_gladiador > 0:
    print("¡VICTORIA!", nombre, "ha ganado la batalla.")
else:
    print("DERROTA. Has caído en combate.")